#include <stdio.h>

int main(){
  char tmp[]="aaaa";
  
  // printf("choississez une chaine de caractère : ");
  // scanf("%s", &tmp);
  
  printf("Voici votre chaine de caractère : \033[41m %s \033[0m \n", tmp); 

  return 0;
}
