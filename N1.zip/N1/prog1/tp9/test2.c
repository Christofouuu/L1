#include <stdio.h>

void changement(char ch[]);

int main() {
    char ch[] = "bbbbbb";
    
    changement(ch);
    
    printf("%s\n", ch);
    
    return 0;
}

void changement(char ch[]){
    int i;
    for(i = 0; ch[i] != '\0'; i++) {
        ch[i] = 'a';
    }
}