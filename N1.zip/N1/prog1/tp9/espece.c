#include <stdio.h>
#include <string.h>
#define LG_MAX 256

struct espece {
	char nom_espece[LG_MAX];
	int nb_pattes;
	int nb_yeux;
	char son[LG_MAX];
};

struct espece saisir_espece();

void afficher_espece(struct espece e);

int main() {
	struct espece chat = { .nom_espece = "chat", .nb_pattes = 4, .nb_yeux = 2 , .son = "miaou"};
	struct espece mygale = { .nom_espece = "mygale", .nb_pattes = 8, .nb_yeux = 8 , .son = "hiiii"};
	struct espece matou;
	matou = chat;
	
	struct espece animal = saisir_espece();
	strcpy(matou.nom_espece, "matou");
	
	afficher_espece(chat);
	afficher_espece(mygale);
	afficher_espece(matou);
	afficher_espece(animal);
	
	return 0;
}

void afficher_espece(struct espece e) {
	printf("Le/la %s a %d pattes et %d yeux. Cet(te) animal produit un son connu tel que %s.\n", e.nom_espece, e.nb_pattes, e.nb_yeux, e.son);
}

struct espece saisir_espece() {
	struct espece e;
	printf("Quel est le nom de votre espèce ? ");
	scanf("%s", e.nom_espece);
	
	printf("Combien de patte(s) a votre espèce ? ");
	scanf("%d", &e.nb_pattes);
	
	printf("Combien de yeux a votre espèce ? ");
	scanf("%d", &e.nb_yeux);
	
	printf("Quel est le son que produit votre espèce ? ");
	scanf("%s", e.son);
	
	return e;
}
