#include <stdio.h>

int main() {
	char chaine[1024];
	int i;
	
	printf("Entrer une chaîne (longueur max 1023) : ");
	scanf("%1023s", chaine);
	
	for (i = 0; i < 1024; i = i + 1) {
		if (chaine[i] == 'a') {
			chaine[i] = 'b';
		} else if (chaine[i] == 'A') {
			chaine[i] = 'B';
		} else if (chaine[i] == 'b') {
			chaine[i] = 'a';
		} else if (chaine[i] == 'B') {
			chaine[i] = 'A';
		}
	}
	printf("%s\n", chaine);

	return 0;
}
