#include <stdio.h>

int main() {
	char ch1[6] = "Hello";
	char ch2[] = "Bob"; /* taille calculée à la compilation */
	char ch3[256];
	ch1[4] = '\0';
	ch2[4] = 'y';
	ch3[0] = 'C';
	ch3[1] = ' ';
	ch3[2] = '+';
	ch3[3] = '+';
	ch3[4] = '\0';
	printf("chaine1 : %s\n", ch1);
	printf("chaine2 : %s\n", ch2);
	printf("chaine3 : %s\n", ch3);	
	
	return 0;
}
