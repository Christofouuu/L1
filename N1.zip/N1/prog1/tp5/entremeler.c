#include <stdio.h>

int main() {
	char chaine[1024], chaine2[1024], mot[2048];
	int i, n = 0, lettre, lettre2;
	
	printf("Première chaîne : ");
	scanf("%1023s", chaine);
	
	printf("Seconde chaîne : ");
	scanf("%1023s", chaine2);
	
	for (lettre = 0; chaine[lettre] != '\0'; lettre = lettre + 1) {
	}
	
	for (lettre2 = 0; chaine2[lettre2] != '\0'; lettre2 = lettre2 + 1) {
	}
	
	if (lettre < lettre2) {
		lettre = lettre2;
	}
	
	for (i = 0; i <= lettre; i = i + 1) {
		mot[n] = chaine[i];
		n = n + 1;
		mot[n] = chaine2[i];
		n = n + 1;
	}
	
	printf("%d, %d, %d\n", lettre, lettre2, i);
	printf("%s\n", mot);

	return 0;
}
