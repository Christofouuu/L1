#include <stdio.h>

int main() {
	char chaine[1024];
	int i, compte = 0, lettre = 0;
	
	printf("Entrer une chaîne (longueur max 1023) : ");
	scanf("%1023s", chaine);
	
	for (lettre = 0; chaine[lettre] != '\0'; lettre = lettre + 1) {
	}
	
	for (i = 0; i < lettre; i = i + 1) {
		if (chaine[i] == 'a') {
			compte = compte + 1;
		} else if (chaine[i] == 'e') {
			compte = compte + 1;
		} else if (chaine[i] == 'i') {
			compte = compte + 1;
		} else if (chaine[i] == 'o') {
			compte = compte + 1;
		} else if (chaine[i] == 'u') {
			compte = compte + 1;
		} else if (chaine[i] == 'y') {
			compte = compte + 1;
		}
	}
	
	printf("Nombre de voyelles : %d\n", compte);
	printf("Longueur de la chaîne : %d\n", lettre);

	return 0;
}
