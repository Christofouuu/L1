#include <stdio.h>
#define MAX_MOT 128

int main() {
	char mot[MAX_MOT];
	int i;
	
	while (scanf("%127s", mot) != EOF) {
		for (i = 0; mot[i] != '\0'; i = i + 1) {
			if (mot[i] >= 97 && mot[i] <= 122) {
				mot[i] = mot[i] - 'a' + 'A';
			}
		}
		printf("%s\n", mot);
	}
	
	return 0;
}
