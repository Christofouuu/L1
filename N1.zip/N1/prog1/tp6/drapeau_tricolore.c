#include <stdio.h>
#define FIN_SAISIE -1
#define TAILLE_MAX 256


int main() {
	int tab[TAILLE_MAX], tab2[TAILLE_MAX];
	int i, taille, n = 0;
	
	printf("Entrer les différents éléments du tableau.\n");
	printf("(-1 pour mettre fin à la saisie)\n");
	for (taille = 0; taille < TAILLE_MAX; taille++) {
		scanf("%d", &tab[taille]);
		if (tab[taille] == FIN_SAISIE) {
			break;
		}
	}
	
	printf("Tableau de taille %d :\n", taille);
	
	for (i = 0; i <= taille; i++) {
		if (tab[i] % 3 == 0) {
			tab2[n] = tab[i];
			n = n + 1;
		}
	}
	
	for (i = 0; i <= taille; i++) {
		if (tab[i] % 3 == 1) {
			tab2[n] = tab[i];
			n = n + 1;
		}
	}
	
	for (i = 0; i <= taille; i++) {
		if (tab[i] % 3 == 2) {
			tab2[n] = tab[i];
			n = n + 1;
		}
	}
	
	for (i = 0; i <= taille ; i++) {
		printf("%d ", tab2[i]);
	}
	
	printf("\n");

	return 0;
}
