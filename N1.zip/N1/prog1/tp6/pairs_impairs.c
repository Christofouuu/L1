#include <stdio.h>
#define FIN_SAISIE -1
#define TAILLE_MAX 256

int main() {
	int tab[TAILLE_MAX], tab1[TAILLE_MAX], taille, i, n = 0;
	
	printf("Entrer les différents éléments du tableau\n");
	printf("(%d pour mettre fin à la saisiee)\n", FIN_SAISIE);
	for (taille = 0; taille < TAILLE_MAX; taille = taille + 1) {
		scanf("%d", &tab[taille]);
		if (tab[taille] == FIN_SAISIE) {
			break;
		}
	}
	
	for (i = 0; i <= taille ; i = i + 1) {
		if (tab[i] % 2 == 0) {
			tab1[n] = tab[i];
			n = n + 1;
		}
	}
	
	for (i = 0; i <= taille; i = i + 1) {
		if(tab[i] % 2 == 1) {
			tab1[n] = tab[i];
			n = n + 1;
		}
	}
	
	printf("Tableau de taille %d :\n", taille);

	for (i = 0; i <= taille ; i = i + 1) {
		printf("%d   ", tab1[i]);
	}
	
	printf("\n");

	return 0;
}
