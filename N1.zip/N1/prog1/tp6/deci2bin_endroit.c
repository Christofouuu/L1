#include <stdio.h>

int main() {
	
	char ch[1024];
	int n, i = 0;
	
	printf("Entrer votre nombre décimal : ");
	scanf("%d", &n);
	
	
	for(i = 0; n > 0; i = i + 1) {
		if (n % 2 == 1) {
			ch[i] = '1';
		} else { 
			ch[i] = '0';
		}
		n = n / 2;
	}
	
	for(i = i - 1; i >= 0; i = i - 1) {
		printf("%c", ch[i]);
	}
	
	printf("\n");
	
	return 0;
}
