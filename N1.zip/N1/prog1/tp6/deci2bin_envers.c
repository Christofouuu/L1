#include <stdio.h>

int main() {

	int n, i, r = 0;
	
	printf("Entrer votre nombre décimal : ");
	scanf("%d", &n);
	
	for(i = n; i > 0; i = i / 2) {
		r = n % 2;
		n = n / 2;
		printf("%d", r);
	}
	
	printf("\n");
	
	return 0;
}
