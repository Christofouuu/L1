#include <stdio.h>

int main() {
	char chaine[20];
	int i, puissance = 1, tab[20];
	
	printf("Entrer un nombre entier >= 0 en décimal (19 chiffres au maximum) : ");
	scanf("%s", chaine);
	
	unsigned long n = 0;
	
	for (i = 0 ; i < 19; i = i + 1) {
		if (chaine[i] != '\0') {
			/* if (chaine[i] == '1') {
				n = n + puissance * 1;
			} else if (chaine[i] == '2') {
				n = n + puissance * 2;
			} else if (chaine[i] == '3') {
				n = n + puissance * 3;
			} else if (chaine[i] == '4') {
				n = n + puissance * 4;
			} else if (chaine[i] == '5') {
				n = n + puissance * 5;
			} else if (chaine[i] == '6') {
				n = n + puissance * 6;
			} else if (chaine[i] == '7') {
				n = n + puissance * 7;
			} else if (chaine[i] == '8') {
				n = n + puissance * 8;
			} else if (chaine[i] == '9') {
				n = n + puissance * 9;
			} else if (chaine[i] == '0') {
				n = n + puissance;
			} */
			/* x = x + puissance * (chaine[i] - '0'); */
			tab[i] = chaine[i] - '0';
		/* puissance = puissance * 10; */
		} else {
			break;
		}
	}
	
	for(i = i - 1; i >= 0; i = i - 1) {
		n = n + (puissance * tab[i]);
		puissance = puissance * 10;
	}
	
	printf("Vous avez entré : %lu\n", n);

	return 0;
}
