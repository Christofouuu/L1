#include <stdio.h>

int main() {
	int n, i;
	
	printf("Entrer  votre nombre décimal : ");
	scanf("%d", &n);

	if (n == 0) {
		printf("0\n");
		return 0;
	}
	
	for (i = 2; i <= n; i = i * 2) {
	}
	
	i = i / 2;
	
	while (i != 0) {
		if (i <= n) {
			printf("1");
			n = n - i;
		} else {
			printf("0");
		}
		i = i / 2;
	}
	
	printf("\n");

	return 0;
}
