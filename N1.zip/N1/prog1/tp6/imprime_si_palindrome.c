#include <stdio.h>
#define MAX_MOT 128
/* TODO: simplifier ce programme. */
int main() {
	char mot[MAX_MOT];
	int i, n, moitie;
	
	while (scanf("%127s", mot) != EOF) {
		for (n = 0; mot[n] != '\0'; n = n + 1) {
		}
		
		n = n - 1;
		
		if (n % 2 == 0) { 
			for (i = 0; i <= n; i++ , n--) {
				if (mot[i] == mot[n]) {
					//printf("mot[%d] = %c, mot[%d] = %c\n", i, mot[i], n, mot[n]);
					if (i == n) {
						printf("%s\n", mot);
						break;
					}
				} else {
					break;
				}
			}
		} else { 
			moitie = n / 2;
			for (i = 0; i <= n; i++ , n--) {
				if (mot[i] == mot[n]) {
					if (i == moitie && n == moitie + 1) {
						printf("%s\n", mot);
						break;
					}
				} else {
					break;
				}
			}
		}		
	}
	
	// printf("%d\n", moitie);
	return 0;
}
