#include <stdio.h>

int main()
{
	/* double permet de déclarer des nombres à virgule, float le fait aussi, mais avec moins de précision */
	double x, carre, cube;
	printf("Entrer un nombre : ");
	/* "%lg" permet de saisir un nombre à birgule */
	scanf("%lg", &x);

	carre = x * x;
	cube = x * carre;
	/* pour imprimer un nombre à virgule sur le terminal il faut utiliser "%lg" */
	printf("%g ^ %d = %lg\n", x, 0, 1.0);
	printf("%g ^ %d = %lg\n", x, 1, x);
	printf("%g ^ %d = %lg\n", x, 2, carre);
	printf("%g ^ %d = %lg\n", x, 3, cube);

	return 0;
}
