#include <stdio.h>
#include <unistd.h> /* pour sleep */

int main()
{
	int nb_carres;

	printf("Le boulottage de tablette de chocolat commence\n");
	printf("Ouverture tablette de chocolat\n");
	printf("Combien de carrés de chocolat ?\n");
	scanf("%d", &nb_carres);

	while (nb_carres > 0) {
		printf("Mangeage d'un carré de chocolat\n");
		printf("Shroumph, shroumph\n");
		sleep(2);
		printf("Le carré est avalé\n");
		nb_carres = nb_carres - 1;
		if (nb_carres > 1) {
			printf("Il reste %d carrés de chocolat\n", nb_carres);
		} else {
			printf("Il reste %d carré de chocolat\n", nb_carres);
		}
	}	
	printf("Tablette boulottée\nJetage de l'emballage.\n");
	printf("Honte...\n");
	return 0;
}
