#include <stdio.h>

int main()
{
	int n, entiers, carres, cubes;

	printf("Somme des entiers, de leurs carrés et de leurs cubes jusqu'à quel nombre ? ");
	scanf("%d", &n);

	entiers = 0;
	carres = 0;
	cubes = 0;
	while (n > 0) {
		entiers = entiers + n;
		/* (n*n) met a la puissance 2 */
		carres = carres + (n * n) ;
		/* (n*n*n) met a la puissance 3 */
		cubes = cubes + ( n * n * n );
		n = n - 1;
	}

	printf("Somme des entiers : %d\n", entiers);
	printf("Sommes des carrés : %d\n", carres);
	printf("Sommes des cubes : %d\n", cubes);
	return 0;
}
