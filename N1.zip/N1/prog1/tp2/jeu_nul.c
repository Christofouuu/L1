#include <stdio.h>

int main()
{
	char chemin, choix;
	
	do
	{
		printf("Bienvenue dans le donjon de la mort.\n");
		printf("Vous êtes devant trois portes.\n");
		printf("Choississez votre chemin (g pour gauche, m pour milieu, d pour 	droite) :\n");
		scanf(" %c", &chemin);
		if (chemin == 'g')
		{
			printf("Des pics sortent du sol et vous embrochent.\n");
			printf("Vous êtes mort...\n");
		}
		else if (chemin == 'm')
		{	
			printf("Des pierres tombent du ciel et vous écrasent. \n");
			printf("Vous êtes mort...\n");
		}
		else if (chemin == 'd')
		{
			printf("De la lave surgit des cotés et vous incinère. \n");
			printf("Vous êtes mort...\n");
		}
		
		printf("Recommencer (o/n) ? ");
		scanf(" %c", &choix);
	} while (choix != 'n');
	
	printf("À bientôt !\n");
	
	return 0;
}
