#include <stdio.h>
#include <unistd.h> /* pour sleep */

int main()
{
	int a, b, c;
	printf("Entrer le nombre à mettre dans a :");
	scanf("%d", &a);

	printf("Entrer le nombre à mettre dans b :");
	scanf("%d", &b);
	
	c = a;
	a = b;
	b = c;
	
	sleep(1);
	
	printf("Echange... \n");
	
	sleep(2);
	
	printf("Maintenant a contient : %d\n", a);
	printf("Maintenant b contient : %d\n", b);
	
	return 0;
}
