#include <stdio.h>

int main()
{
	int a, b, c;
	
	printf("Entrer le premier nombre :");
	scanf("%d", &a);
	
	printf("Entrer le second nombre :");
	scanf("%d", &b);
	
	printf("Entrer le troisième nombre :");
	scanf("%d", &c);
	
	if (a > b) {
		if (b > c) {
			printf("Le plus petit nombre est : %d\n", c);
		} else {
			printf("Le plus petit nombre est : %d\n", b);
		}
	} else {
		if (a > c) {
			printf("Le plus petit nombre est : %d\n", c);
		} else  {
			printf("Le plus petit nombre est : %d\n", a);
			}
	}
	
	return 0;
}
