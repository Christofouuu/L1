#include <stdio.h>
#include <unistd.h> /* pour sleep */

int main()
{
	int a, b;
	printf("Entrer le nombre à mettre dans a :");
	scanf("%d", &a);

	printf("Entrer le nombre à mettre dans b :");
	scanf("%d", &b);
	
	sleep(1);
	
	printf("Echange... \n");
	
	sleep(2);
	
	printf("Maintenant a contient : %d\n", b);
	printf("Maintenant b contient : %d\n", a);
	
	return 0;
}
