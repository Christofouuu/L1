#include <stdio.h>
#include <unistd.h>

int main()
{
	int a, b;
	char reponse;

	printf("Entrer le premier nombre : ");
	scanf("%d", &a);
	printf("Entrer le deuxième nombre : ");
	scanf("%d", &b);

	printf("Quelle opération (a pour addition, m pour multiplication, s pour soustraction, d pour division) ? ");
	scanf(" %c", &reponse);
	
	if (reponse == 'a') 
	{
		printf("Résultat : %d\n", a + b);
	}
	
	else if (reponse == 'm')
	{
		printf("Résultat : %d\n", a * b);
	}
	
	else if (reponse == 's')
	{
		printf("Résultat : %d\n", a - b);
	}
	
	else if (reponse == 'd')
	{
		printf("Le quotient de la division : %d\n", a / b);
		printf("Le reste de la division : %d\n", a % b );
	}
	
	else
	{
		printf("ERREUR\nCaractère non reconnue. \n");
		sleep(2);
		printf("Arrêt du programme \n");
	}
	
	return 0;
}
