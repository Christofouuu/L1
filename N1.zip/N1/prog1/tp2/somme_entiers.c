#include <stdio.h>

int main()
{
	int n, res;

	printf("Somme des entiers jusqu'à quel nombre ? ");
	scanf("%d", &n);

	res = 0;
	while (n > 0) {
		res = res + n;
		n = n - 1;
	}

	printf("Résultat : %d\n", res);
	return 0;
}
